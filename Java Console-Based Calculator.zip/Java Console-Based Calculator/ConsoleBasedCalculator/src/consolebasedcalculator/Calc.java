package consolebasedcalculator;

import java.util.*;
/**
 * This program is a console-based scientific calculator.05
 * 
 * @author Ifedolapo Omolara Ajayi(Student1345890)
 * @author Asmau Ismail(Student1344165)
 * @version 1.0
 */

public  class Calc {
    
    //this is the main method
    public static void main(String[]args){
        Scanner scan = new Scanner(System.in); //this is the scanner class
        int num1, num2, options, num, length, no, d, gcd=1; 
        int originalNumber, remainder, result = 0, n = 0;
        String palindrome, reverse = ""; //Objects of String class
        double answer, numone, res=0;
        boolean on = true;

        System.out.print("### THIS CALCULATOR CAN PERFORM TWENTY-SIX SCIENTIFIC OPERATIONS USING ONLY TWO NUMBERS ###");
        while (on){

            System.out.print("\n1.  Addition ");
            System.out.print("\t\t2.  Subtraction ");
            System.out.print("\t\t3.  Multiplication ");
            System.out.print("\t\t4.  Division ");
            System.out.println("\t\t5.  Power ");
            System.out.print("6.  Square ");
            System.out.print("\t\t7.  Cube ");
            System.out.print("\t\t\t8.  Square Root");
            System.out.print("\t\t\t9.  Round ");
            System.out.println("\t\t10. Ceiling ");
            System.out.print("11. Floor ");
            System.out.print("\t\t12. Min Value ");
            System.out.print("\t\t\t13. Max Value ");
            System.out.print("\t\t\t14. Sin ");
            System.out.println("\t\t15. Cos ");
            System.out.print("16. Asin ");
            System.out.print("\t\t17. Acos ");
            System.out.print("\t\t\t18. Atan ");
            System.out.print("\t\t\t19. Exponential ");
            System.out.println("       20. Palindrome");
            System.out.print("21. Armstrong Number ");
            System.out.print("\t22. Prime Number ");
            System.out.print("\t\t23. Average ");
            System.out.print("\t\t\t24. GCD"); 
            System.out.println("\t\t\t25. LCM");
            System.out.println("26. Exit");
            System.out.print("\nPlease enter the number of the operation you want to execute: ");
            scan.hasNextInt();
            options = scan.nextInt();

            try{
                //System.out.println("Enter Number1 ");

                //System.out.println("Enter Number2 "_);                                                                        
                //options = scan.nextInt();
                switch (options){

                    case 1:  //addition
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();

                    System.out.println("Enter Number2 ");
                    num2 = scan.nextInt();
                    
                    answer = num1 + num2;
                    System.out.println("The result is " +answer);
                    break;

                    case 2:   //subtraction:
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();

                    System.out.println("Enter Number2 ");
                    num2 = scan.nextInt();
                    
                    answer = num1 - num2;
                    System.out.println("The result is " +answer);
                    break;

                    case 3:  // multiplication:
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();

                    System.out.println("Enter Number2 ");
                    num2 = scan.nextInt();
                    
                    answer = num1 * num2;
                    System.out.println("The result is " +answer);
                    break;

                    case  4:   //division:
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();

                    System.out.println("Enter Number2 ");
                    num2 = scan.nextInt();
                    
                    answer = num1 / num2;
                    System.out.println("The result is " +answer);
                    break;

                    case 5:  //power: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();

                    System.out.println("Enter Number2 ");
                    num2 = scan.nextInt();
                    
                    System.out.println("The answer is " +Math.pow(num1,num2));
                    break;
                    
                    case 6:  //square: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();
                    
                    System.out.println("The answer is " +Math.pow(num1,2));
                    break;
                    
                    case 7:  //cube: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();
                    
                    System.out.println("The answer is " +Math.pow(num1,3));
                    break;

                    case 8: //squareRoot:
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();
                    
                    System.out.println("The answer is " +Math.sqrt(num1));
                    break;
                    
                    case 9:  //round: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    numone= scan.nextDouble();
                    System.out.println("The answer is " +Math.round(numone));
                    break;
                    
                    case 10:  //ceiling: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    numone= scan.nextDouble();
                    System.out.println("The answer is " +Math.ceil(numone));
                    break;
                    
                    case 11:  //floor: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    numone= scan.nextDouble();
                    System.out.println("The answer is " +Math.floor(numone));
                    break;
                    
                    case 12:  //min value: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();

                    System.out.println("Enter Number2 ");
                    num2 = scan.nextInt();
                    System.out.println("The minimum value is " +Math.min(num1,num2));
                    break;
                    
                    case 13:  //max value: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();

                    System.out.println("Enter Number2 ");
                    num2 = scan.nextInt();
                    System.out.println("The maximum value is " +Math.max(num1,num2));
                    break;
                    
                    case 14:  //sin: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();
                    System.out.println("The answer is " +Math.sin(num1));
                    break;
                    
                    case 15:  //cos: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();
                    System.out.println("The answer is " +Math.cos(num1));
                    break;
                    
                    case 16:  //asin: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();
                    System.out.println("The answer is " +Math.asin(num1));
                    break;
                    
                    case 17:  //acos: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();
                    System.out.println("The answer is " +Math.acos(num1));
                    break;
                    
                    case 18:  //atan: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();
                    System.out.println("The answer is " +Math.atan(num1));
                    break;
                    
                    case 19:  //exponential: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    numone= scan.nextDouble();
                    System.out.println("The answer is " +Math.exp(numone)); /** return (2.718281828459045) power of numone
                                                            * Input Zero, Output 1.0
                                                            * Input positive Infinity, Output positive Infinity
                                                            * Input negative Infinity, Output Zero
                                                            * Input NaN, Output NaN
                                                            */
                    break;
                    
                    case 20:  //palindrome: 
                    //System.out.print('\u000C');
                    System.out.println("Number of digits to be entered: ");
                    no=scan.nextInt();
                    if(no>2){
                    System.out.println("Enter a string/number to check if it is at least a three digit number:");
                    num=scan.nextInt();
                    if(num>99){
                    System.out.println("Enter a string/number to check if it is a palindrome:");
                    palindrome= scan.next();
                    length = palindrome.length();
                    for ( int i = length - 1; i >= 0; i-- )  
                    reverse = reverse + palindrome.charAt(i);  
                    if (palindrome.equals(reverse))  
                    System.out.println("The number you entered is a palindrome.");  
                    else  
                    System.out.println("The number you entered is not a palindrome.");
                    }
                    else{
                    System.out.println("Please enter at least a three digit number!");
                    }
                    }
                    else{
                        System.out.println("Please enter at least a three digit number!");
                    }
                    break;
                    
                    case 21:  //armstrong number: 
                    //System.out.print('\u000C');
                    System.out.println("Enter a number to check if it is an armstrong number");
                    num1= scan.nextInt();
                    
                    originalNumber = num1;
                    for (;originalNumber != 0; originalNumber /= 10, ++n);
                    
                    originalNumber = num1;
                    for (;originalNumber != 0; originalNumber /= 10)
                        {
                           remainder = originalNumber % 10;
                           result += Math.pow(remainder, n);
                        }
                    if(result == num1)
                      System.out.println(num1 + " is an Armstrong number.");
                    else
                      System.out.println(num1 + " is not an Armstrong number.");
                    break;
                    
                    case 22:  //prime number: 
                    //System.out.print('\u000C');
                    System.out.println("Enter a number to check if it is an prime number");
                    num1= scan.nextInt();
                    boolean flag = false;
                    for (int i = 2; i <= num1 / 2; ++i) {
                    // condition for nonprime number
                    if (num1 % i == 0) {
                    flag = true;
                    break;
                    }
                    }

                    if (!flag)
                     System.out.println(num1 + " is a prime number.");
                    else
                     System.out.println(num1 + " is not a prime number.");
                    break;

                    case 23: //Average:
                    //System.out.print('\u000C');
                    System.out.println("Enter how many numbers to calculate average for: ");
                    d= scan.nextInt(); 
                    int a[] = new int[d];
                    System.out.println("Enter "+d+" numbers: ");
                    for(int i=0;i<d;i++)
                        a[i] = scan.nextInt();
                    
                    for(int i=0;i<d;i++)
                        res = res + a[i];
                    
                    System.out.println("Average is "+res/d);
                    break;
                    
                    case 24:  //gcd: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt(); //will read first input from user

                    System.out.println("Enter Number2 ");
                    num2 = scan.nextInt(); //will read second input from user
                    
                    num1 = ( num1 > 0) ? num1 : -num1;
                    num2 = ( num2 > 0) ? num2 : -num2;

                    while(num1 != num2) {
        
                    if(num1 > num2) {
                    num1 -= num2;
                    }
      
                    else {
                    num2 -= num1;
                    }
                    }
    
                    System.out.println("The GCD: " + num1); //prints the GCD
                    break;
                    
                    case 25:  //lcm: 
                    //System.out.print('\u000C');
                    System.out.println("Enter Number1 ");
                    num1= scan.nextInt();

                    System.out.println("Enter Number2 ");
                    num2 = scan.nextInt();
                    
                    for(int i = 1; i <= num1 && i <= num2; ++i) {
                    // Checks if i is factor of both integers
                    if(num1 % i == 0 && num2 % i == 0)
                    gcd = i;
                    }

                    int lcm = (num1 * num2) / gcd;
                    System.out.printf("The LCM of %d and %d is %d.", num1, num2, lcm);
                    break;

                    case 26: //to terminate the program
                    System.out.println("Calculator successfully exited. Goodbye.");
                    System.exit(0);
                    break;

                    default:
                    System.out.println("Hello");
                    System.out.print('\u000C');

                }

            }
            catch(NumberFormatException e){
                //catch(Exception e){
                System.out.printf("Wrong number or not enough numbers");

            }
            /* while(options == 0){
            break;
            }*/
        }
    }
}
